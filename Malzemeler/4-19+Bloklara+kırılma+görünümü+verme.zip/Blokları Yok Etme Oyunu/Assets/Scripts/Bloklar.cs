﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bloklar : MonoBehaviour {

    public int can;
    public int vurulmaSayisi;
    private SahneKontrolu sahneYoneticisi;
    public Sprite[] blokGorunumleri;
	// Use this for initialization
	void Start () {
        vurulmaSayisi = 0;
        sahneYoneticisi = GameObject.FindObjectOfType<SahneKontrolu>();
        
	}

    private void OnCollisionEnter2D(Collision2D collision)
    {
        vurulmaSayisi++;
        //vurulmaSayisi = vurulmaSayisi + 1;
        //vurulmaSayisi += 1;
        if(vurulmaSayisi >= can)
        {
            Destroy(gameObject);
        }
        else
        {
            BlokGoruntusunuDegistir();
        }
        
    }

    public void BlokGoruntusunuDegistir()
    {
        //vurulma sayisi = 1
        this.GetComponent<SpriteRenderer>().sprite = blokGorunumleri[vurulmaSayisi - 1];

    }


    public void SonrakiSahne()
    {
        sahneYoneticisi.SonrakiSahne();
    }

    
}
